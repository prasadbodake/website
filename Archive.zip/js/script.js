document.addEventListener('DOMContentLoaded', function() {
    // Initialize carousel
    initCarousel();
    
    // Initialize product details
    initProductDetails();
    
    // Initialize screenshot slider
    initScreenshotSlider();
    
    // Initialize contact form
    initContactForm();
    
    // Initialize mobile menu
    initMobileMenu();
});

// Carousel functionality
function initCarousel() {
    const slides = document.querySelectorAll('.carousel-slide');
    const dots = document.querySelectorAll('.dot');
    const prevBtn = document.querySelector('.carousel-btn.prev');
    const nextBtn = document.querySelector('.carousel-btn.next');
    
    if (!slides.length) return;
    
    let currentSlide = 0;
    const totalSlides = slides.length;
    
    function showSlide(index) {
        slides.forEach(slide => slide.classList.remove('active'));
        dots.forEach(dot => dot.classList.remove('active'));
        
        slides[index].classList.add('active');
        dots[index].classList.add('active');
    }
    
    function nextSlide() {
        currentSlide = (currentSlide + 1) % totalSlides;
        showSlide(currentSlide);
    }
    
    function prevSlide() {
        currentSlide = (currentSlide - 1 + totalSlides) % totalSlides;
        showSlide(currentSlide);
    }
    
    // Event listeners
    if (prevBtn) prevBtn.addEventListener('click', prevSlide);
    if (nextBtn) nextBtn.addEventListener('click', nextSlide);
    
    dots.forEach((dot, index) => {
        dot.addEventListener('click', () => {
            currentSlide = index;
            showSlide(currentSlide);
        });
    });
    
    // Auto-advance carousel
    setInterval(nextSlide, 5000);
}

// Product details functionality
function initProductDetails() {
    const urlParams = new URLSearchParams(window.location.search);
    const productName = urlParams.get('name') || 'webcam-capture';

    const productData = {
        'webcam-capture': {
            title: 'Webcam Capture',
            description: 'Monitor, record & detect motion effortlessly. Multi-camera support with 4-way preview. Auto-upload to OneDrive & instant email alerts.',
            longDescription: 'Welcome to Webcam Capture, the next-gen solution to turn your humble webcam into a powerhouse surveillance dynamo. Perfect for both cozy homes 🏡 and bustling businesses 🏢, this tool is packed with top-tier features ensuring your space is always secure and you are always in the know.',
            image: 'images/webcam-capture-features.jpeg',
            screenshots: [
                'images/webcam-capture/apps.20276.14443446189475378.946154be-2aff-413a-8c65-b44680aa90e3.a25000ae-d99c-4cda-80a4-4222564c3cd4',
                'images/webcam-capture/apps.346.14443446189475378.946154be-2aff-413a-8c65-b44680aa90e3.0e5e6d66-0f3a-4c61-9564-ec8c94064cd2',
                'images/webcam-capture/apps.59741.14443446189475378.65204bd4-012c-4442-aaf0-ca66fe282db6.d80250ed-3976-4350-90c3-caaf6f88f3e2'
            ],
            features: ['Webcam Preview', 'Webcam Video Recording', 'Motion Detection', 'Auto Upload to OneDrive', 'Email Alerts'],
            downloadUrl: 'https://apps.microsoft.com/detail/9nwl3cg9qsq1?ocid=webpdpshare'
        },
        'duplicate-file-cleaner-pro': {
            title: 'Duplicate File Cleaner Pro',
            description: 'Declutter your PC with Duplicate File Cleaner Pro! - Find and remove duplicate files across images, documents, videos, and more with precision.',
            longDescription: 'Duplicate File Cleaner Pro is a powerful tool that helps you find and remove duplicate files across images, documents, videos, and more with precision. It is a must-have for anyone who wants to declutter their PC and free up space.',
            image: 'images/duplicate-file-cleaner-pro.jpeg',
            screenshots: [
                'images/duplicate-file-cleaner-pro/apps.29346.14498231556830356.0a7d06e0-836f-4e44-934e-cd983d834843.b844647b-dd19-49c2-9f6a-1e45b317be45',
                'images/duplicate-file-cleaner-pro/apps.28797.14498231556830356.0a7d06e0-836f-4e44-934e-cd983d834843.784074e6-be3c-4a5f-aad1-f291ca996f8c',
                'images/duplicate-file-cleaner-pro/apps.10293.14498231556830356.df30c145-1178-425e-a3e2-32537d34e9d6.01f20f8b-dd7b-4981-b4dd-a3b690e2245e'
            ],
            features: ['Content-Based Scanning: Analyzes file content for precise duplicate detection, even with different filenames.',
                 'Intelligent Removal: Recommends duplicates for deletion based on file content and type.',
                  'Diverse Deletion Modes: Choose from Recycle Bin, Permanent Delete, or Archive for flexibility.',
                   'Streamlined UI: User-friendly interface for efficient content-driven file management.',
                    'Rapid Scanning: Swiftly scans and compares file content, saving you valuable time.'],
            downloadUrl: 'https://apps.microsoft.com/detail/9p257b4wlhfk?ocid=webpdpshare'
        },
        'desk-time-monitor': {
            title: 'Desk Time Monitor',
            description: 'Monitor work hours, app usage, & browsed sites with real-time insights. Capture efficiency with screenshots. Level up goals.',
            longDescription: 'Desk Time Monitor is a productivity tool that helps you track your work hours, app usage, and browsed sites with real-time insights. It captures efficiency with screenshots and helps you level up your goals.',
            image: 'images/desktime-monitor.jpeg',
            screenshots: [
                'https://images.unsplash.com/photo-1677442136019-21780ecad995?w=800&h=500&fit=crop',
                'https://images.unsplash.com/photo-1676299251956-415118d0178c?w=800&h=500&fit=crop',
                'https://images.unsplash.com/photo-1519125323398-675f0ddb6308?w=800&h=500&fit=crop'
            ],
            features: ['Precise Time Tracking: Accurately monitor every second of your workday to optimize time management.', 
                'Website Usage Analysis: Identify and manage distractions with real-time website tracking.', 
                'Configurable Screenshots: Customize screenshot intervals to capture work progress effectively.',
                 'Login & Logout Monitoring: Track login times to understand work patterns and productivity.',
                  'Auto start: Automatically start Desk Time Monitor with Windows for effortless tracking.'],
            downloadUrl: 'https://apps.microsoft.com/detail/9pj8fsp43rf4?ocid=webpdpshare'
        }
    };
    
    const product = productData[productName];
    if (!product) {
        // Handle product not found, maybe redirect to a 404 page or show a default message
        return;
    }
    
    // Update page title for SEO
    document.title = `${product.title} - ZenByte Apps`;
    
    // Update product details
    const productTitle = document.querySelector('.product-info h2');
    const productDesc = document.querySelector('.product-info p');
    const productImage = document.querySelector('.product-image img');
    const downloadBtn = document.querySelector('.btn-download');
    
    if (productTitle) productTitle.textContent = product.title;
    if (productDesc) productDesc.textContent = product.longDescription;
    if (productImage) {
        productImage.src = product.image;
        productImage.alt = product.title; // Add alt text for SEO
    }

    if (downloadBtn && product.downloadUrl) {
        downloadBtn.href = product.downloadUrl;
        downloadBtn.target = '_blank';
        downloadBtn.rel = 'noopener noreferrer';
    }
    
    // Add features list
    const productInfo = document.querySelector('.product-info');
    if (productInfo && product.features) {
        const featuresList = document.createElement('div');
        featuresList.className = 'product-features-list';
        featuresList.innerHTML = `
            <h3>Key Features</h3>
            <ul>
                ${product.features.map(feature => `<li><i class="fas fa-check"></i> ${feature}</li>`).join('')}
            </ul>
        `;
        productInfo.appendChild(featuresList);
    }
    
    // Populate screenshot slider section
    const screenshotSliderSection = document.querySelector('.screenshot-slider');
    if (screenshotSliderSection) {
        if (product.screenshots && product.screenshots.length > 0) {
            screenshotSliderSection.innerHTML = `
                <h3>Product Screenshots</h3>
                <div class="screenshot-container">
                    <div class="screenshot-slides">
                        ${product.screenshots.map(screenshot => `
                            <div class="screenshot-slide">
                                <img src="${screenshot}" alt="${product.title} Screenshot">
                            </div>
                        `).join('')}
                    </div>
                    <button class="screenshot-nav prev"><i class="fas fa-chevron-left"></i></button>
                    <button class="screenshot-nav next"><i class="fas fa-chevron-right"></i></button>
                </div>
                <div class="screenshot-dots">
                    ${product.screenshots.map((_, index) => `
                        <span class="screenshot-dot ${index === 0 ? 'active' : ''}" data-slide="${index}"></span>
                    `).join('')}
                </div>
            `;
            // Immediately initialize the slider after injecting HTML
            console.log('Injecting screenshot slider for', product.title);
            initScreenshotSlider();
        } else {
            screenshotSliderSection.innerHTML = '<p style="text-align:center;color:#888;">No screenshots available for this product.</p>';
            console.log('No screenshots found for', product.title);
        }
    }
}

// Screenshot slider functionality
function initScreenshotSlider() {
    const screenshotSlides = document.querySelector('.screenshot-slides');
    const screenshotDots = document.querySelectorAll('.screenshot-dot');
    const prevBtn = document.querySelector('.screenshot-nav.prev');
    const nextBtn = document.querySelector('.screenshot-nav.next');
    
    if (!screenshotSlides) return;
    
    let currentSlide = 0;
    const totalSlides = screenshotDots.length;
    
    function showScreenshot(index) {
        screenshotSlides.style.transform = `translateX(-${index * 100}%)`;
        screenshotDots.forEach(dot => dot.classList.remove('active'));
        screenshotDots[index].classList.add('active');
    }
    
    function nextScreenshot() {
        currentSlide = (currentSlide + 1) % totalSlides;
        showScreenshot(currentSlide);
    }
    
    function prevScreenshot() {
        currentSlide = (currentSlide - 1 + totalSlides) % totalSlides;
        showScreenshot(currentSlide);
    }
    
    // Event listeners
    if (prevBtn) prevBtn.addEventListener('click', prevScreenshot);
    if (nextBtn) nextBtn.addEventListener('click', nextScreenshot);
    
    screenshotDots.forEach((dot, index) => {
        dot.addEventListener('click', () => {
            currentSlide = index;
            showScreenshot(currentSlide);
        });
    });
}

// Contact form functionality
function initContactForm() {
    const contactForm = document.getElementById('contactForm');
    
    if (contactForm) {
        contactForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const name = document.getElementById('name').value;
            const email = document.getElementById('email').value;
            const subject = document.getElementById('subject')?.value || 'General Inquiry';
            const message = document.getElementById('message').value;
            
            if (name && email && message) {
                // Show success message
                showNotification(`Thank you for your message, ${name}! We will get back to you at ${email} as soon as possible.`, 'success');
                contactForm.reset();
            } else {
                showNotification('Please fill out all required fields.', 'error');
            }
        });
    }
}

// Mobile menu functionality
function initMobileMenu() {
    const mobileMenuBtn = document.querySelector('.mobile-menu-btn');
    const navLinks = document.querySelector('.nav-links');
    
    if (mobileMenuBtn && navLinks) {
        mobileMenuBtn.addEventListener('click', () => {
            navLinks.classList.toggle('active');
        });
    }
}

// Notification system
function showNotification(message, type = 'info') {
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.innerHTML = `
        <div class="notification-content">
            <span>${message}</span>
            <button class="notification-close"><i class="fas fa-times"></i></button>
        </div>
    `;
    
    document.body.appendChild(notification);
    
    // Auto-remove after 5 seconds
    setTimeout(() => {
        notification.remove();
    }, 5000);
    
    // Close button functionality
    const closeBtn = notification.querySelector('.notification-close');
    if (closeBtn) {
        closeBtn.addEventListener('click', () => {
            notification.remove();
        });
    }
}

// Smooth scrolling for anchor links
document.querySelectorAll('a[href^="#"]:not([href="#"])').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        const target = document.querySelector(this.getAttribute('href'));
        if (target) {
            const headerOffset = 80; // Height of the fixed header
            const elementPosition = target.getBoundingClientRect().top;
            const offsetPosition = elementPosition + window.pageYOffset - headerOffset;

            window.scrollTo({
                top: offsetPosition,
                behavior: 'smooth'
            });
        }
    });
}); 